// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyA4lDKrgROxVu_H2VQ1IaddGTX-6wU7uWw",
  authDomain: "auth-firebase-carine-aula1.firebaseapp.com",
  projectId: "auth-firebase-carine-aula1",
  storageBucket: "auth-firebase-carine-aula1.appspot.com",
  messagingSenderId: "759582026151",
  appId: "1:759582026151:web:21bc242fee47a3bf3aee82",
  measurementId: "G-WHX7HDEELK"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

export default app;